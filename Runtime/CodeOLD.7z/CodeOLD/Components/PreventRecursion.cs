﻿namespace VarianceAPI.Components
{
    /// <summary>
    /// idk why youre here, this component just exists to avoid variants resurrecting multiple times, lol
    /// </summary>
    public class PreventRecursion : VariantComponent
    {
        //lol. <--- This lol was left by Rob, i hope his game goes well.
    }
}