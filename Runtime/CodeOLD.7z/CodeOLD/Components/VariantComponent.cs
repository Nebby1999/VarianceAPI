﻿using UnityEngine;

namespace VarianceAPI.Components
{
    public class VariantComponent : MonoBehaviour
    {
    }
}
