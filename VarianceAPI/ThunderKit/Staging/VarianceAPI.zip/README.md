# Variance API

A complete continuation of Rob's Original MonsterVariants mod.


The API by itself currently doesnt do much, but theoretically all the ground work is done for the creation of custom variants.

It is not advised to replace your Variants mods with this API just yet, as its in early development.

Currently supports all *(i think)* the previous features of MonsterVariants, alongside a new MonsterVariantTier and a very basic implementation of MonsterVariantsPlus' Rewards system.

## Todo's

	- Continue development of the API

	- Start working on proper Thunderkit support


## Changelog
'0.0.1'

* Initial Release